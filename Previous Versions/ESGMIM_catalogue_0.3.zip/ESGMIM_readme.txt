Welcome to ver. 0.3 of the National Seismic Hazard Model Earthquake Source and Ground 
Motion Intensity Measure catalogue (there is currently no clever name, sadly)! Here you 
will find several tables, which include data for M >= 4 data (from the original GeoNet 
database) with high quality ground motion intensity measures:

	-Earthquake Source Table
	-Site Table
	-Station Magnitude Table
	-Phase Arrival Table
	-Propagation Path Table
	-Earthquake Ground Motion Intensity Measure Catalogue
	
These tables can easily be read into almost any programs, as they are CSV files. They
were created using the Pandas module for Python.

More information on the tables can be found on our in-progress Wiki! All relevant tables
are linked to from the Related Resources category below the table descriptions:

https://wiki.canterbury.ac.nz/display/QuakeCore/Ground+Motion+Intensity+Measure+Catalogue

Current Version Implementations:
- v 0.3 - Accompanying figures have been added to the ESGMIM package in .png format.

Previous Version Information:
- v 0.2 - The GM IM catalogue has been divided into three separate documents for 000, 090,
	and vertical components. The site table contains additional site response data.
- v 0.1 - Includes complete subset catalogue with GM IM and relocation data for M >= 4 
	GM IM data. As includes tectonic class measurements.
- v 0.0 - First version. Incomplete and without the addition of relocated data.
